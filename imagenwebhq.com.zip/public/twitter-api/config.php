<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'N6fwAMSBuyi12KXnKIT2a3TUc');
    define('CONSUMER_SECRET', '20UJ0gL0MvVzCaKceyvilxn9vPFEXzrQqGahS2XjmpueyIEcy6');

    // User Access Token
    define('ACCESS_TOKEN', '515022146-TW0YzSFUcM3AgdkqvZTyzh4F5wYL47zB13J6dFie');
    define('ACCESS_SECRET', 'Hi1bsyFqF325DMZozKyJiYkYHCcxYL5oz9pM4N8rdQt6r');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));

